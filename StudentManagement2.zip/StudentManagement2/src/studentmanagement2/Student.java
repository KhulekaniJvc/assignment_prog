/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studentmanagement2;

/**
 *
 * @author lab_services_student
 */
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lab_services_student
 */


import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import java.util.Scanner;
import java.util.Collections;

/**
 *
 * @author Plamedi
 */
public class Student {
    int mainOption = 0;
    String menuOptionInput;
    int menuOption = 0;
    int studentId = 0;
    String studentName;
    int studentAge = 0;
    String studentEmail;
    String studentCourse;
    int searchStudentId;
    int deleteStudentId;

    Scanner input = new Scanner(System.in);
    public List<Integer> studentIds = new ArrayList<>();
    public List<String> studentNames = new ArrayList<>();
    public List<Integer> studentAges = new ArrayList<>();
    public List<String> studentEmails = new ArrayList<>();
    public List<String> studentCourses = new ArrayList<>();

    public void showMessage() {
        do {
            // Prompt the user to launch the menu or exit
            mainOption = Integer.parseInt(JOptionPane.showInputDialog("STUDENT MANAGEMENT APPLICATION\n"
                    + "*********************************************************************\n"
                    + "Enter (1) to launch menu or any other key to exit "));

            switch (mainOption) {
                case 1:
                    showMenu();
                    break;
            }
        } while (mainOption != 1);
        return;
    }

    public String showMenu() {
        do {
            // Prompt the user to select a menu item
            menuOptionInput = JOptionPane.showInputDialog("Please select one of the following menu Items below: \n"
                    + "(1) Capture a new Student.\n(2) Search for a Student.\n(3) Delete a student. \n(4) Print student report. \n(5) Exit Application");
            menuOption = Integer.parseInt(menuOptionInput);
            switch (menuOption) {
                case 1:
                    // Capture student information
                    studentName = JOptionPane.showInputDialog("Enter Student name ");
                    studentId = Integer.parseInt(JOptionPane.showInputDialog("Enter Student ID"));
                    studentAge = Integer.parseInt(JOptionPane.showInputDialog("Enter your Age"));
                    checkAgeRequirement();
                    studentCourse = JOptionPane.showInputDialog("Enter your Course");
                    studentEmail = JOptionPane.showInputDialog("Enter your email");
                    // Display captured student information
                    JOptionPane.showMessageDialog(null, "CAPTURE A NEW STUDENT\n"
                            + "******************************\n" + "Student ID: " + studentId + "\nStudent name: " + studentName + "\nStudent Age: " + studentAge + "\nStudent Course: " + studentCourse + "\nStudent email: " + studentEmail);
                    storeStudentData();
                    break;
                case 2:
                    searchStudent();
                    break;
                case 3:
                    deleteStudent();
                    break;
                case 4:
                    printStudentReport();
                    break;
                case 5:
                    exitApplication();
                    break;
            }
        } while (menuOption != 6);

        // Close the input stream
        input.close();
        return showMenu();
    }

    public void storeStudentData() {
        // Store student information in ArrayLists
        studentNames.add(studentName);
        studentAges.add(studentAge);
        studentIds.add(studentId);
        studentCourses.add(studentCourse);
        studentEmails.add(studentEmail);
    }

    public void checkAgeRequirement() {
        // Check and prompt for a valid student age
        while (studentAge < 16) {
            JOptionPane.showMessageDialog(null, "You have entered an incorrect student age. Please re-enter.");
            studentAge = Integer.parseInt(JOptionPane.showInputDialog("Enter your Age"));
        }
    }

    public void searchStudent() {
        // Prompt the user to enter a student ID for searching
        searchStudentId = Integer.parseInt(JOptionPane.showInputDialog("Enter Student ID you wish to search:"));

        for (int i = 0; i < studentIds.size(); i++) {
            if (studentIds.get(i).equals(searchStudentId)) {
                // Display information for the found student
                studentName = studentNames.get(i);
                studentId = studentIds.get(i);
                studentAge = studentAges.get(i);
                studentCourse = studentCourses.get(i);
                studentEmail = studentEmails.get(i);
                StringBuilder message = new StringBuilder("\n Student ID assigned to " + searchStudentId + " found\n");
                message.append("-----------------------------------------------------");
                message.append(" \n Student Name: " + studentName + "\n");
                message.append(" Student Age: " + studentAge + "\n");
                message.append(" Student Course: " + studentCourse + "\n");
                message.append("Student Email: " + studentEmail + "\n");
                message.append("Student ID: " + studentId + "\n");
                message.append("-----------------------------------------------------");
                JOptionPane.showMessageDialog(null, message.toString());
                return;
            }
        }

        JOptionPane.showMessageDialog(null, "\n Student ID assigned to " + searchStudentId + " not found\n");
    }

    public void deleteStudent() {
        // Prompt the user to enter a student ID for deletion
        deleteStudentId = Integer.parseInt(JOptionPane.showInputDialog("Enter Student ID to delete"));
        int indexToDelete = Collections.binarySearch(studentIds, deleteStudentId);
        if (indexToDelete >= 0) {
            int choice = JOptionPane.showConfirmDialog(null, "Do you want to delete the Student ID: " + deleteStudentId + " from the system", "ARE YOU SURE", JOptionPane.YES_NO_OPTION);
            if (choice == JOptionPane.YES_OPTION) {
                // Remove the student's information based on the index found by binary search
                studentNames.remove(indexToDelete);
                studentIds.remove(indexToDelete);
                studentAges.remove(indexToDelete);
                studentCourses.remove(indexToDelete);
                studentEmails.remove(indexToDelete);
                JOptionPane.showMessageDialog(null, "Student ID: " + deleteStudentId + " has been deleted from the system.");
            }
        } else {
            JOptionPane.showMessageDialog(null,
                    "No Student ID assigned to " + deleteStudentId + " found in the system."
            );
        }
    }

    public void printStudentReport() {
        // Generate a report of all stored student information
        for (int i = 0; i < studentIds.size(); i++) {
            studentName = studentNames.get(i);
            studentId = studentIds.get(i);
            studentAge = studentAges.get(i);
            studentCourse = studentCourses.get(i);
            studentEmail = studentEmails.get(i);
            StringBuilder message = new StringBuilder("STUDENT " + (i + 1) + "\n");
            message.append("-----------------------------------------------------");
            message.append(" \n Student Name: " + studentName + "\n");
            message.append(" Student Age: " + studentAge + "\n");
            message.append(" Student Course: " + studentCourse + "\n");
            message.append("Student Email: " + studentEmail + "\n");
            message.append("Student ID: " + studentId + "\n");
            message.append("-----------------------------------------------------");
            System.out.println(message.toString());
        }
    }

    public void exitApplication() {
        // Display an exit message and terminate the application
        JOptionPane.showMessageDialog(null, "Exiting Application.......");
        System.exit(0);
    }
}
