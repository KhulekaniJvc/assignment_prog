/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package studentmanagement2;

/**
 *
 * @author lab_services_student
 */
public class StudentManagement2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     Student poe  = new Student();
     
     poe.showMessage();
    }
    
}

 /*Title: Arrays In Java Tutorial #10
 *Author: Alex Lee
 *Date: 2019
 *Code version:
 *Availabiltiy: https://youtu.be/xzjZy-dHHLw?si=gGuPF2tpg30MJ7GP
*/