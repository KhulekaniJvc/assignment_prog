package Question2 ;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FoodDeliverySystem {
    static class FoodItem {
        private String name;
        private double price;

        public FoodItem(String name, double price) {
            this.name = name;
            this.price = price;
        }

        public String getName() {
            return name;
        }

        public double getPrice() {
            return price;
        }

        @Override
        public String toString() {
            return name + " - $" + price;
        }
    }

    static class Order {
        private List<FoodItem> items;
        private String customerName;
        private String deliveryAddress;

        public Order(String customerName, String deliveryAddress) {
            this.items = new ArrayList<>();
            this.customerName = customerName;
            this.deliveryAddress = deliveryAddress;
        }

        public void addItem(FoodItem item) {
            items.add(item);
        }

        public double getTotalPrice() {
            double total = 0;
            for (FoodItem item : items) {
                total += item.getPrice();
            }
            return total;
        }

        public String getCustomerName() {
            return customerName;
        }

        public String getDeliveryAddress() {
            return deliveryAddress;
        }

        @Override
        public String toString() {
            StringBuilder orderDetails = new StringBuilder();
            orderDetails.append("Order for ").append(customerName).append("\n");
            orderDetails.append("Delivery Address: ").append(deliveryAddress).append("\n");
            orderDetails.append("Items:\n");
            for (FoodItem item : items) {
                orderDetails.append(item).append("\n");
            }
            orderDetails.append("Total Price: $").append(getTotalPrice()).append("\n");
            return orderDetails.toString();
        }
    }

    static class Delivery {
        private Order order;
        private String status;

        public Delivery(Order order) {
            this.order = order;
            this.status = "Pending";
        }

        public void updateStatus(String status) {
            this.status = status;
        }

        public String getStatus() {
            return status;
        }

        @Override
        public String toString() {
            return "Delivery Status: " + status + "\n" + order;
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<FoodItem> menu = new ArrayList<>();
        menu.add(new FoodItem("Burger", 5.99));
        menu.add(new FoodItem("Pizza", 8.99));
        menu.add(new FoodItem("Soda", 1.50));

        System.out.println("Welcome to the Food Delivery System!");

        // Display menu
        System.out.println("Menu:");
        for (int i = 0; i < menu.size(); i++) {
            System.out.println((i + 1) + ". " + menu.get(i));
        }

        // Take order
        System.out.print("Enter your name: ");
        String name = scanner.nextLine();
        System.out.print("Enter delivery address: ");
        String address = scanner.nextLine();

        Order order = new Order(name, address);

        while (true) {
            System.out.print("Enter the number of the food item to add to your order (0 to finish): ");
            int choice = scanner.nextInt();
            if (choice == 0) break;
            if (choice > 0 && choice <= menu.size()) {
                order.addItem(menu.get(choice - 1));
            } else {
                System.out.println("Invalid choice. Try again.");
            }
        }

        // Create delivery
        Delivery delivery = new Delivery(order);

        // Display order and delivery status
        System.out.println("\nYour Order Summary:");
        System.out.println(delivery);

        // Update delivery status
        System.out.print("Update delivery status (e.g., 'Delivered'): ");
        scanner.nextLine(); // Consume newline
        String status = scanner.nextLine();
        delivery.updateStatus(status);

        // Display updated delivery status
        System.out.println("\nUpdated Delivery Status:");
        System.out.println(delivery);

        scanner.close();
    }
}
