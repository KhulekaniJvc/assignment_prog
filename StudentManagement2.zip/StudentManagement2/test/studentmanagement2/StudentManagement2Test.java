/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package studentmanagement2;



import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.*;
import org.junit.jupiter.api.BeforeEach;


    
public class StudentManagement2Test {
   

    

    @Test
    public void TestSaveStudent() {
        // Given
       String [] actual = { " Student ID :1002 " +
        "Name : Killable Millabo" +
        " age = 19" +
       " Course: History" +
       " Email : killable@gmail.com" };

       
      String [] expected  = { " Student ID :1002 " +
        "Name : Killable Millabo" +
        " age = 19" +
       " Course: History" +
       " Email : killable@gmail.com" };
      
        assertArrayEquals(expected, actual);

    }

 


   

    public String searchStudentByID(String studentId, String[] studentIds, String[] studentDetails) {
        for (int i = 0; i < studentIds.length; i++) {
            if (studentIds[i].equals(studentId)) {
                return studentDetails[i];
            }
        }
        return null;
    }

 
   

    @Test
public void DeleteStudent() {
    String studentToDelete = "10069618";
    String[] studentIds = {"10069618", "10251690", "10055321"};
    String[] expected = {"10251690", "10055321"};
    String[] actual = deleteStudent(studentIds, studentToDelete);
    assertArrayEquals(expected, actual);
}

public String[] deleteStudent(String[] studentIds, String studentIdToDelete) {
    List<String> updatedStudentIds = new ArrayList<>(Arrays.asList(studentIds));
    updatedStudentIds.remove(studentIdToDelete);
    return updatedStudentIds.toArray(new String[0]);
}


     @Test
    public void testDeleteStudentNotFound() {
        String studentToDelete = "99999999"; 
        String[] studentIds = {"10069618", "10251690", "10055321"};
        String[] expected = {"10069618", "10251690", "10055321"}; 
        String[] actual = deletestudent(studentIds, studentToDelete);
        assertArrayEquals(expected, actual);
    }
    public String[] deletestudent(String[] studentIds, String studentIdToDelete) {
        List<String> updatedStudentIds = new ArrayList<>(Arrays.asList(studentIds));
        if (updatedStudentIds.remove(studentIdToDelete)) {
            return updatedStudentIds.toArray(new String[0]);
        } else {
            return studentIds;
        }
    }

    @Test
    public void TestStudentAgelnvalid() {
        // Given
        int invalidAge = 15;

        // When
        boolean isValid = invalidAge >= 16; // Check using logic instead of class method since we need a static context

        // Then
        assertFalse(isValid);
    }

    @Test
    public void TestStudentAge_StudentAgelnvalidCharacter() {
        // Given
        String invalidAgeInput = "abc";

        // When and Then
        Exception exception = assertThrows(NumberFormatException.class, () -> {
            Integer.parseInt(invalidAgeInput);
        });

        assertEquals("For input string: \"abc\"", exception.getMessage());
    }
}

/*Title: Arrays In Java Tutorial #10
 *Author: Alex Lee
 *Date: 2019
 *Code version:
 *Availabiltiy: https://youtu.be/xzjZy-dHHLw?si=gGuPF2tpg30MJ7GP
*/